import{ useState } from 'react';
import PropTypes from 'prop-types';
import './App.css';



function Header({ title }) {
  return (
    <header>
      <h1>{title}</h1>
    </header>
  );
}

Header.propTypes = {
  title: PropTypes.string.isRequired,
};


function Content() {
  const [displayText, setDisplayText] = useState('');
  const [text, setText] = useState('');

  const handleButtonClick = () => {
    setDisplayText(text);
  };

  const handleTextAreaChange = (event) => {
    setText(event.target.value);
  };

  return (
    <main>
      <textarea value={text} onChange={handleTextAreaChange} placeholder="Type Bro..." />
      <button onClick={handleButtonClick}>Display Text</button>
      {displayText && <p>{displayText}</p>}
    </main>
  );
}


function Footer() {
  return (
    <footer>
      <p>Your life Can not be Fucked up without the Most Important Ingredient-</p>
      <h4>-You-</h4>
    </footer>
  );
}


function App() {
  return (
    <div className="App">
      <Header title="Enter Your Fev Quote" />
      <Content />
      <Footer />
    </div>
  );
}

export default App;
